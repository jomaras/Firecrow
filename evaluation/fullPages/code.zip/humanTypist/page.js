$(document).ready(function() {
    $("#example").humanTypist({
        'speed' : 'hacker'
    })
});